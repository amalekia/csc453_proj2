Adrick Malekian, Jack Ary

Helpful Notes:
    - Demo prep:
        $ LD_LIBRARY_PATH=../lib64/
        $ export LD_LIBRARY_PATH

